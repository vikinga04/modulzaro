import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {

  elso!: number;
  masodik!: number;
  harmadik!: number;
  hosegRiadoSzint!: string;

  aktualisRiadoSzint(): void {
    if (this.elso && this.masodik && this.harmadik) {
      const atlagHomerseklet = (this.elso + this.masodik + this.harmadik) / 3;

      if (atlagHomerseklet >= 30) {
        this.hosegRiadoSzint = 'Magas';
      } else if (atlagHomerseklet >= 25) {
        this.hosegRiadoSzint = 'Közepes';
      } else if (atlagHomerseklet >= 20) {
        this.hosegRiadoSzint = 'Alacsony';
      } else {
        this.hosegRiadoSzint = 'Nincs riadó';
      }
    }
  }

  mentettRiadok: string[] = [];

  mentes(): void {
    if (this.elso && this.masodik && this.harmadik) {
      this.aktualisRiadoSzint();
      this.mentettRiadok.push(this.hosegRiadoSzint || 'Nincs adat');
      console.log('Adatok elmentve!');
    } else {
      console.log('Nem lehet menteni, mert valamelyik érték hiányzik!');
    }
  }
}