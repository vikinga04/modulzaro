import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-kektura',
  templateUrl: './kektura.component.html',
  styleUrls: ['./kektura.component.css']
})
export class KekturaComponent {


  turaSzakasz: any[] = [
    "Sumeg, vasutallomas;Sumeg, buszpalyaudvar;1,208;16;6;n",
    "Sumeg, buszpalyaudvar;Mogyorosi-domb, geologiai bemutatohely;1,512;24;8;n",
    "Mogyorosi-domb, geologiai bemutatohely;Sumegi bazaltbanya vasutallomas;1,576;13;43;n",
    "Sumegi bazaltbanya vasutallomas;Sarvaly erdeszhaz, pecsetelohely;2,101;69;18;i",
    "Sarvaly erdeszhaz, pecsetelohely;Leteres a foldutrol a romos vadaszhaznal;4,25;82;66;n",
    "Leteres a foldutrol a romos vadaszhaznal;Kek rom jelzes kezdete Tatika varahoz;2,686;172;29;n",
    "Kek rom jelzes kezdete Tatika varahoz;Hidegkuti major;1,614;9;135;n",
    "Hidegkuti major;Leteres a Sztupahoz;3,903;153;53;n",
    "Leteres a Sztupahoz;Zalaszanto, romai katolikus templom pecsetelohely;2,747;14;148;i",
    "Zalaszanto, romai katolikus templom;Leteres az orszagutrol Rezi fele;2,396;26;51;n",
    "Leteres az orszagutrol Rezi fele;Rezi, leteres a pecsetelohelyhez;3,328;112;13;i",
    "Rezi, leteres a pecsetelohelyhez;Gyongyosi csarda pecsetelohely;2,535;31;173;i",
    "Gyongyosi csarda;Egregy, arpad-kori templom;5,239;134;109;n",
    "Egregy, arpad-kori templom;Heviz, leteres az autobuszallomashoz pecsetelohely;2,595;20;49;i",
    "Heviz, leteres az autobuszallomashoz;Keszthely, Festetics kastely eszaki kapuja;5,114;58;32;n",
    "Keszthely, Festetics kastely eszaki kapuja;Keszthely, leteres a vasutallomashoz pecsetelohely;1,82;3;36;i",
  ]


  ObjektumFeltolto(feltoltendoElem: string[]): turaSzakasz[] {
    var beolvasottAdatok: turaSzakasz[] = [];
    for (let i: number = 0; i < feltoltendoElem.length; i++) {
      let elemDarabok: string[] = feltoltendoElem[i].split(";");
      let ujObjektum: turaSzakasz = {
        kiinduloPont: elemDarabok[0],
        vegPont: elemDarabok[1],
        szakaszHossza: Number(elemDarabok[2]),
        emelkedes: Number(elemDarabok[3]),
        lejtes: Number(elemDarabok[4]),
        pecsetelohelyE: elemDarabok[5] === 'n'
      };
      beolvasottAdatok.push(ujObjektum);
    }
    return beolvasottAdatok;
  }

  megjelenitendoAdatok: turaSzakasz[] = this.ObjektumFeltolto(this.turaSzakasz)


  mentes() {
    if (this.turaForm.valid) {
      let ujObjektum: turaSzakasz = {
        kiinduloPont: this.ujTura.kiinduloPont,
        vegPont: this.ujTura.vegPont,
        szakaszHossza: Number(this.ujTura.szakaszHossza),
        emelkedes: Number(this.ujTura.emelkedes),
        lejtes: Number(this.ujTura.lejtes),
        pecsetelohelyE: this.ujTura.pecsetelohelyE === 'true'
      };
      this.turaSzakasz.push(ujObjektum);
      this.ujTura = {};
    } else {
      alert('Hiányzó adat! Töltse ki az összes mezőt a mentéshez.');
    }
  }

  ujTura: turaSzakasz = {
    kiinduloPont: '',
    vegPont: '',
    szakaszHossza: 0,
    emelkedes: 0,
    lejtes: 0,
    pecsetelohelyE: false
  };

  mentesek() {
    if (this.turaForm.valid) {
      this.turaSzakasz.push(this.ujTura);
      this.ujTura = {
        kiinduloPont: '',
        vegPont: '',
        szakaszHossza: 0,
        emelkedes: 0,
        lejtes: 0,
        pecsetelohelyE: false
      };

    }
  }
}

export interface turaSzakasz {
  kiinduloPont: string;
  vegPont: string;
  szakaszHossza: number;
  emelkedes: number;
  lejtes: number;
  pecsetelohelyE: boolean;

}
